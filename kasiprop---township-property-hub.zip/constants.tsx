
import { Property, PropertyType, BusinessSubtype } from './types';

export const SUPPORTED_TOWNSHIPS = [
  { 
    name: 'Soweto', 
    aliases: ['Sowe', 'Jozi South', 'Orlando', 'Diepkloof'], 
    region: 'Johannesburg',
    subAreas: ['Orlando West', 'Orlando East', 'Diepkloof', 'Pimville', 'Jabulani', 'Meadowlands'],
    landmarks: ['Jabulani Mall', 'Chris Hani Baragwanath', 'Vilakazi Street', 'Maponya Mall', 'Baragwanath Rank']
  },
  { 
    name: 'Khayelitsha', 
    aliases: ['Khaye', 'Site B', 'Site C', 'Makhaza'], 
    region: 'Cape Town',
    subAreas: ['Site B', 'Site C', 'Makhaza', 'Harare', 'Kuyasa', 'Bongweni'],
    landmarks: ['Site B Taxi Rank', 'Khayelitsha Mall', 'Lookout Hill', 'Enkanini']
  },
  { 
    name: 'Tembisa', 
    aliases: ['Tembi', 'Winnie Mandela', 'Kempton South'], 
    region: 'Ekurhuleni',
    subAreas: ['Winnie Mandela', 'Oakmoor', 'Esangweni', 'Hospital View', 'Clayville'],
    landmarks: ['Phuthaditjaba Center', 'Tembisa Hospital', 'Oakmoor Station', 'Sethokga']
  }
];

export const MOCK_PROPERTIES: Property[] = [
  {
    id: '1',
    title: 'Secure En-suite + Spaza Space',
    description: 'Neat en-suite room in a walled yard. Yard has a street-facing gate perfect for a spaza or fruit stall. Very safe and quiet area.',
    price: 2800,
    isNegotiable: true,
    marketPriceInsight: 'Listed at R2,800, but similar units here close at R2,500.',
    location: 'Soweto, Orlando West',
    township: 'Soweto',
    landmarks: ['5 min walk to Vilakazi St', 'Behind Orlando West High', 'Near Maponya Mall'],
    propertyType: PropertyType.MIXED_USE,
    businessSubtype: BusinessSubtype.SPAZA,
    images: ['https://picsum.photos/seed/prop1/800/600'],
    verified: true,
    yardSize: '320sqm',
    developmentPotential: ['Spaza', 'Salon', 'Single Backroom'],
    trustSignals: {
      tenure: 'Owner since 2017',
      responseTime: 'Replies in <30 mins',
      successfulRentals: 8,
      localReferrer: 'Verified by Street Committee'
    },
    communityPulse: { recentEnquiries: 14, saves: 42 },
    lastUpdated: new Date(Date.now() - 1000 * 60 * 60 * 2),
    availabilityConfirmed: true,
    features: ['Private Bathroom', 'Secure Parking', 'WiFi Ready', 'Street Frontage', 'Reliable Water'],
    areaIntelligence: {
      noise: 'Moderate',
      walkability: '10 min walk to taxi rank',
      commute: 'Easy access to Putco buses',
      safety: 'Active neighborhood watch area',
      footTraffic: 'High during morning/afternoon taxi times'
    }
  },
  {
    id: '2',
    title: 'Corner Retail Space (Site B)',
    description: 'Prime business spot right near the rank. Massive foot traffic all day. Secure gate and storage room.',
    price: 4500,
    isNegotiable: false,
    location: 'Khayelitsha, Site B',
    township: 'Khayelitsha',
    landmarks: ['Opposite Site B Taxi Rank', 'Near Khayelitsha Mall'],
    propertyType: PropertyType.BUSINESS_SPACE,
    businessSubtype: BusinessSubtype.RETAIL,
    images: ['https://picsum.photos/seed/prop2/800/600'],
    verified: true,
    trustSignals: {
      tenure: 'Managed by local agency',
      responseTime: 'Replies in <2hrs',
      successfulRentals: 15
    },
    communityPulse: { recentEnquiries: 31, saves: 112 },
    lastUpdated: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3),
    availabilityConfirmed: false,
    features: ['High Foot Traffic', 'Security Gates', 'Storage Space', 'Shopfront Access', 'Power Reliability'],
    areaIntelligence: {
      noise: 'Busy',
      walkability: 'Right at the transport hub',
      commute: 'Immediate taxi access',
      safety: 'Security guard on-site',
      footTraffic: 'Heavy flow all day'
    }
  },
  {
    id: '4',
    title: 'Investment Property: Large 450sqm Yard',
    description: 'Perfect for development. Large yard in a high-demand rental area. Existing 2-bedroom house can be used while building 4-6 backrooms.',
    price: 450000,
    isNegotiable: true,
    location: 'Soweto, Jabulani',
    township: 'Soweto',
    landmarks: ['Near Jabulani Mall', 'Near Bheki Mlangeni Hospital'],
    propertyType: PropertyType.RESIDENTIAL,
    images: ['https://picsum.photos/seed/prop4/800/600'],
    verified: true,
    yardSize: '450sqm',
    developmentPotential: ['4-6 Backrooms', 'Retail Units', 'Mini-Warehouse'],
    trustSignals: {
      tenure: 'Owner since 2012',
      responseTime: 'Replies same day',
      successfulRentals: 2
    },
    communityPulse: { recentEnquiries: 8, saves: 25 },
    lastUpdated: new Date(Date.now() - 1000 * 60 * 60 * 12),
    availabilityConfirmed: true,
    features: ['Large Open Yard', 'Zoned Residential', 'Water Meter Installed'],
    areaIntelligence: {
      noise: 'Quiet',
      walkability: 'Near schools and malls',
      commute: 'Quick access to Soweto Highway',
      safety: 'Established section'
    }
  }
];
