
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { UserIntent, PropertyType, Property, Urgency, BusinessSubtype, InquiryPurpose } from './types';
import { MOCK_PROPERTIES } from './constants';
import { Filters } from './components/Filters';
import { PropertyCard } from './components/PropertyCard';
import { PropertyDetails } from './components/PropertyDetails';
import { getPropertyMatchAnalysis, MatchAnalysis } from './services/geminiService';

const App: React.FC = () => {
  const [intent, setIntent] = useState<UserIntent>({
    budgetMin: 0,
    budgetMax: 5000,
    propertyType: PropertyType.RESIDENTIAL,
    purpose: InquiryPurpose.RENT,
    location: 'Soweto',
    subArea: undefined,
    urgency: Urgency.MONTH,
    businessSubtype: BusinessSubtype.SPAZA,
    selectedFeatures: []
  });

  const [savedPropertyIds, setSavedPropertyIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('kasiprop_saved');
    return saved ? JSON.parse(saved) : [];
  });

  const [selectedPropertyId, setSelectedPropertyId] = useState<string | null>(null);
  const [analyses, setAnalyses] = useState<Record<string, MatchAnalysis>>({});
  const [loadingAnalyses, setLoadingAnalyses] = useState(false);
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('kasiprop_saved', JSON.stringify(savedPropertyIds));
  }, [savedPropertyIds]);

  const toggleSaveProperty = useCallback((e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setSavedPropertyIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  }, []);

  const filteredProperties = useMemo(() => {
    return MOCK_PROPERTIES.filter(p => {
      // Purpose-based filtering logic
      if (intent.purpose === InquiryPurpose.INVEST) {
        // Investors look for purchase opportunities or large developable yards
        if (p.price <= 15000) return false; // Rent properties aren't usually for sale investment
      } else {
        // Regular users shouldn't see multi-million buy properties unless explicitly searching to Buy
        if (p.price > 100000 && intent.purpose !== InquiryPurpose.BUY && intent.purpose !== InquiryPurpose.INVEST) return false;
        if (p.price < 100000 && (intent.purpose === InquiryPurpose.BUY || intent.purpose === InquiryPurpose.INVEST)) return false;
      }

      const townshipMatch = !intent.location || p.township.toLowerCase() === intent.location.toLowerCase();
      const typeMatch = intent.purpose === InquiryPurpose.INVEST || p.propertyType === intent.propertyType;
      const budgetMatch = p.price <= intent.budgetMax;
      const featuresMatch = intent.selectedFeatures.every(sf => p.features.includes(sf));

      return townshipMatch && typeMatch && budgetMatch && featuresMatch;
    });
  }, [intent]);

  const updateAnalyses = useCallback(async () => {
    setLoadingAnalyses(true);
    const newAnalyses: Record<string, MatchAnalysis> = { ...analyses };
    const analysisPromises = filteredProperties.map(async (p) => {
      if (!newAnalyses[p.id]) {
        try {
          const result = await getPropertyMatchAnalysis(p, intent);
          newAnalyses[p.id] = result;
        } catch (err) {
          console.error(`Failed analysis for ${p.id}`, err);
        }
      }
    });
    await Promise.all(analysisPromises);
    setAnalyses(newAnalyses);
    setLoadingAnalyses(false);
  }, [intent, filteredProperties]);

  useEffect(() => {
    updateAnalyses();
  }, [intent.propertyType, intent.purpose, intent.budgetMax, intent.location, intent.selectedFeatures.length]);

  const selectedProperty = MOCK_PROPERTIES.find(p => p.id === selectedPropertyId);

  const nudge = useMemo(() => {
    if (savedPropertyIds.length >= 3) {
      return {
        title: `Ready to Build Wealth?`,
        body: `You've saved ${savedPropertyIds.length} properties. Some have great potential for backroom development. Want to compare their estimated ROI?`,
        icon: <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
      };
    }
    return null;
  }, [savedPropertyIds.length]);

  if (selectedProperty) {
    return (
      <PropertyDetails 
        property={selectedProperty} 
        analysis={analyses[selectedProperty.id] || null} 
        userIntent={intent}
        onBack={() => setSelectedPropertyId(null)} 
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#f8fafc] flex flex-col">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-black text-xl">K</span>
            </div>
            <span className="text-xl font-black text-slate-900 tracking-tight">KasiProp</span>
          </div>
          <div className="flex items-center gap-4">
             <button className="relative p-2 text-slate-500 hover:text-indigo-600 transition-colors">
               <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
               {savedPropertyIds.length > 0 && <span className="absolute top-0 right-0 w-4 h-4 bg-rose-500 text-white text-[10px] font-black rounded-full flex items-center justify-center border-2 border-white">{savedPropertyIds.length}</span>}
             </button>
             <div className="w-10 h-10 rounded-full bg-slate-100 overflow-hidden border border-slate-200">
               <img src="https://picsum.photos/seed/user/100" alt="Avatar" />
             </div>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        <div className="max-w-4xl mx-auto">
          {nudge && (
            <div className="mb-8 bg-slate-900 text-white p-6 rounded-[2.5rem] shadow-2xl flex flex-col sm:flex-row items-center gap-6 border border-slate-800 animate-in slide-in-from-top-4 duration-500">
              <div className="w-14 h-14 bg-rose-500/20 text-rose-400 rounded-2xl flex items-center justify-center shrink-0">{nudge.icon}</div>
              <div className="flex-1 text-center sm:text-left">
                <h4 className="text-lg font-black tracking-tight mb-1">{nudge.title}</h4>
                <p className="text-sm font-bold text-slate-400 leading-relaxed">{nudge.body}</p>
              </div>
              <button className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-4 rounded-2xl font-black text-sm uppercase tracking-widest transition-all active:scale-95">Compare ROI</button>
            </div>
          )}

          <section className="mb-8 text-center sm:text-left">
            <h1 className="text-4xl sm:text-5xl font-black text-slate-900 mb-4 tracking-tight leading-tight">
              Build Your <span className="text-indigo-600">Township Future</span>
            </h1>
            <p className="text-lg sm:text-xl text-slate-500 font-medium max-w-2xl leading-relaxed italic">
              Find space to live, space to hustle, or space to build wealth. Verified local knowledge.
            </p>
          </section>

          <div className="hidden lg:block">
            <Filters intent={intent} setIntent={setIntent} />
          </div>

          <div className="flex items-center justify-between mb-8 sticky top-20 bg-[#f8fafc]/80 backdrop-blur-sm py-2 z-30 lg:z-0 lg:static">
            <h2 className="text-sm font-black text-slate-400 uppercase tracking-[0.2em]">{filteredProperties.length} Opportunities Found</h2>
            {loadingAnalyses && <div className="flex items-center gap-2 text-indigo-600 text-xs font-black animate-pulse bg-indigo-50 px-4 py-2 rounded-full">Syncing AI Guide...</div>}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {filteredProperties.map(p => (
              <PropertyCard key={p.id} property={p} analysis={analyses[p.id] || null} isSaved={savedPropertyIds.includes(p.id)} onToggleSave={(e) => toggleSaveProperty(e, p.id)} onClick={() => setSelectedPropertyId(p.id)} />
            ))}
          </div>
        </div>
      </main>

      <footer className="bg-slate-900 border-t border-slate-800 py-12 mt-12">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-slate-800 rounded-lg flex items-center justify-center"><span className="text-white font-black text-sm">K</span></div>
            <span className="text-slate-400 font-black tracking-tight uppercase">KasiProp Township Intel</span>
          </div>
          <div className="flex gap-10">
            <a href="#" className="text-slate-500 hover:text-white text-xs font-black uppercase tracking-widest">Privacy</a>
            <a href="#" className="text-slate-500 hover:text-white text-xs font-black uppercase tracking-widest">Terms</a>
            <a href="#" className="text-slate-500 hover:text-white text-xs font-black uppercase tracking-widest">Contact Kasi Stockfellas</a>
          </div>
        </div>
      </footer>

      {isFilterOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex flex-col sm:items-center sm:justify-center">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setIsFilterOpen(false)} />
          <div className="relative bg-white w-full h-full sm:h-[90vh] sm:max-w-2xl sm:rounded-[2.5rem] flex flex-col shadow-2xl p-6">
             <div className="flex items-center justify-between mb-6">
               <h3 className="text-xl font-black text-slate-900 tracking-tight">Refine Your Search</h3>
               <button onClick={() => setIsFilterOpen(false)} className="p-2 bg-slate-100 rounded-full">
                 <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12"/></svg>
               </button>
             </div>
             <Filters intent={intent} setIntent={setIntent} />
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
