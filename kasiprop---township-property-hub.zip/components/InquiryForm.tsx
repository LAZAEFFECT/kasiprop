
import React, { useState, useMemo } from 'react';
import { Property, UserIntent, Urgency, InquiryPurpose, PropertyType } from '../types';

interface InquiryFormProps {
  property: Property;
  userIntent: UserIntent;
  onClose: () => void;
  onSubmit: (summary: string) => void;
}

export const InquiryForm: React.FC<InquiryFormProps> = ({ property, userIntent, onClose, onSubmit }) => {
  const [purpose, setPurpose] = useState<InquiryPurpose>(userIntent.purpose);
  const [developmentType, setDevelopmentType] = useState('Backrooms');
  const [urgency, setUrgency] = useState<Urgency>(userIntent.urgency);
  const [importance, setImportance] = useState('Safety');
  const [sending, setSending] = useState(false);

  const ownerSummary = useMemo(() => {
    if (purpose === InquiryPurpose.INVEST) {
      return `Serious investor enquiry. Interested in ${developmentType} development. Priority: ${importance}. Ready to move in ${urgency.toLowerCase()}. Budget: R${userIntent.budgetMax.toLocaleString()}.`;
    }
    return `Serious ${purpose.toLowerCase()} enquiry. Priority: ${importance}. Ready to move ${urgency.toLowerCase()}. Budget: R${userIntent.budgetMax.toLocaleString()}.`;
  }, [purpose, urgency, developmentType, importance, userIntent.budgetMax]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSending(true);
    setTimeout(() => {
      onSubmit(ownerSummary);
      setSending(false);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-md z-50 flex items-end sm:items-center justify-center p-4">
      <div className="bg-white w-full max-w-xl rounded-t-[2.5rem] sm:rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="px-8 py-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
          <div>
            <span className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.2em] mb-1 block">Local Guide Intent Check</span>
            <h3 className="font-black text-slate-900 text-2xl tracking-tight">Your {purpose} Plan</h3>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-full transition-colors"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12"/></svg></button>
        </div>

        <form onSubmit={handleSubmit} className="overflow-y-auto px-8 py-6 space-y-8">
          {purpose === InquiryPurpose.INVEST && (
            <div className="space-y-4">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">What do you want to build?</label>
              <div className="flex flex-wrap gap-2">
                {['Backrooms', 'Retail/Units', 'Mini-Warehouse', 'Spaza Corner'].map(item => (
                  <button key={item} type="button" onClick={() => setDevelopmentType(item)} className={`px-5 py-3 rounded-xl text-xs font-black border transition-all ${developmentType === item ? 'bg-indigo-600 text-white' : 'bg-slate-50 text-slate-500'}`}>{item}</button>
                ))}
              </div>
            </div>
          )}

          <div className="space-y-4">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">What's your priority?</label>
            <div className="flex flex-wrap gap-2">
              {['Safety', 'Taxi Access', 'Yard Space', 'Quiet Section'].map(item => (
                <button key={item} type="button" onClick={() => setImportance(item)} className={`px-5 py-3 rounded-xl text-xs font-black border transition-all ${importance === item ? 'bg-indigo-50 border-indigo-300 text-indigo-700' : 'bg-white border-slate-200 text-slate-500'}`}>{item}</button>
              ))}
            </div>
          </div>

          <div className="bg-slate-900 rounded-[2rem] p-6 text-white border border-slate-800">
            <span className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.2em] block mb-3">Owner Summary (KasiProp Intel)</span>
            <p className="text-sm font-medium leading-relaxed italic opacity-90 leading-relaxed">"{ownerSummary}"</p>
          </div>
        </form>

        <div className="p-8 bg-white border-t border-slate-100 flex gap-4">
           <button type="button" onClick={onClose} className="px-6 text-sm font-black text-slate-400 uppercase tracking-widest">Cancel</button>
           <button type="button" onClick={handleSubmit} disabled={sending} className="flex-1 py-5 bg-indigo-600 text-white font-black text-lg rounded-2xl shadow-xl hover:bg-indigo-700 transition-all active:scale-[0.98] disabled:opacity-50">
             {sending ? 'Sending to Owner...' : 'Confirm Intent'}
           </button>
        </div>
      </div>
    </div>
  );
};
