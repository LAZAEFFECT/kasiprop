
import React from 'react';
import { Property, PropertyType } from '../types';
import { Badge } from './Badge';
import { MatchAnalysis } from '../services/geminiService';

interface PropertyCardProps {
  property: Property;
  analysis: MatchAnalysis | null;
  isSaved: boolean;
  onToggleSave: (e: React.MouseEvent) => void;
  onClick: () => void;
}

export const PropertyCard: React.FC<PropertyCardProps> = ({ 
  property, 
  analysis, 
  isSaved, 
  onToggleSave, 
  onClick 
}) => {
  const getFreshnessLabel = (date: Date) => {
    const diff = Date.now() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    if (days === 0) return 'Updated today';
    if (days === 1) return 'Updated yesterday';
    return `Updated ${days} days ago`;
  };

  return (
    <div 
      onClick={onClick}
      className="bg-white rounded-[2rem] overflow-hidden shadow-sm border border-slate-200 hover:shadow-xl hover:border-indigo-100 transition-all cursor-pointer group flex flex-col h-full"
    >
      <div className="relative h-52 overflow-hidden">
        <img 
          src={property.images[0]} 
          alt={property.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
        />
        <div className="absolute top-4 left-4 flex flex-wrap gap-2 items-start max-w-[85%]">
          {property.propertyType === PropertyType.MIXED_USE && (
            <Badge variant="verified" icon={<svg className="w-3 h-3" fill="currentColor" viewBox="0 0 24 24"><path d="M12 3l1.5 1.5 2.1-.3.3 2.1 1.5 1.5-1.5 1.5-.3 2.1-2.1-.3L12 12.6l-1.5-1.5-2.1.3-.3-2.1-1.5-1.5 1.5-1.5.3-2.1 2.1.3L12 3z"/></svg>}>
              Home + Hustle
            </Badge>
          )}
          <Badge variant="info" icon={<svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" strokeWidth="2.5" strokeLinecap="round"/></svg>}>
            {property.trustSignals.tenure}
          </Badge>
        </div>

        {/* Community Pulse Overlay */}
        <div className="absolute bottom-4 left-4">
           <div className="bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/20 flex items-center gap-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
              <span className="text-[10px] font-black text-white uppercase tracking-widest">{property.communityPulse.recentEnquiries} enquiries this week</span>
           </div>
        </div>

        {analysis && (
          <div className="absolute bottom-4 right-4">
             <div className="bg-white px-3 py-1.5 rounded-2xl shadow-xl border border-indigo-100">
                <span className="text-xs font-black text-indigo-600 tracking-tighter uppercase">Match </span>
                <span className="text-sm font-black text-slate-900">{analysis.score}%</span>
             </div>
          </div>
        )}
      </div>

      <div className="p-6 flex flex-col flex-1">
        <div className="flex justify-between items-start mb-3">
          <h3 className="font-black text-slate-900 text-lg leading-tight line-clamp-1">{property.title}</h3>
          <div className="text-right">
            <span className="text-indigo-600 font-black text-xl leading-none block">R {property.price.toLocaleString()}</span>
            {property.isNegotiable && <span className="text-[9px] font-black text-green-600 uppercase tracking-widest">Negotiable</span>}
          </div>
        </div>
        
        <p className="text-slate-500 text-sm mb-4 font-bold flex items-center gap-2 italic">
          <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
          {property.landmarks[0] || property.location}
        </p>

        {analysis && (
          <div className="mb-6">
             <p className="text-slate-600 bg-slate-50 px-4 py-3 rounded-2xl text-xs leading-relaxed font-bold border border-slate-100">
               "{analysis.summary}"
             </p>
          </div>
        )}

        <div className="mt-auto flex justify-between items-center text-[10px] text-slate-400 font-black pt-4 border-t border-slate-100 uppercase tracking-widest">
          <span>{getFreshnessLabel(property.lastUpdated)}</span>
          <div className="flex items-center gap-4">
            <button 
              onClick={onToggleSave}
              className={`flex items-center gap-1.5 transition-all active:scale-90 ${isSaved ? 'text-rose-500' : 'text-slate-400 hover:text-rose-500'}`}
              aria-label={isSaved ? "Unsave property" : "Save property"}
            >
              <svg 
                className={`w-4 h-4 ${isSaved ? 'fill-current' : 'fill-none'}`} 
                stroke="currentColor" 
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/>
              </svg>
              {isSaved ? 'Saved' : 'Save'}
            </button>
            <span className="flex items-center gap-1 text-indigo-500 font-black">
              View Space
              <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M9 5l7 7-7 7"/></svg>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
