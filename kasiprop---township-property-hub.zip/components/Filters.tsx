
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { UserIntent, PropertyType, BusinessSubtype, Urgency, InquiryPurpose } from '../types';
import { SUPPORTED_TOWNSHIPS } from '../constants';

interface FiltersProps {
  intent: UserIntent;
  setIntent: (intent: UserIntent) => void;
}

const RESIDENTIAL_FEATURES = [
  'Perimeter Wall', 'Reliable Water', 'Backup Power', 'Private Bathroom', 
  'Built-in Cupboards', 'Secure Parking', 'WiFi Ready', 'Security Lights'
];

const BUSINESS_FEATURES = [
  'Shopfront Access', 'High Foot Traffic', 'Power Reliability', 
  'Security Gates', 'Loading Area', 'Storage Space', 'Street Frontage'
];

const INVEST_FEATURES = [
  'Large Open Yard', 'Water Meter', 'Prepaid Electricity', 'Zoned Residential',
  'Near Schools', 'Near Taxi Rank', 'Corner Stand'
];

export const Filters: React.FC<FiltersProps> = ({ intent, setIntent }) => {
  const [showAllFeatures, setShowAllFeatures] = useState(false);
  const [locationInput, setLocationInput] = useState(intent.location + (intent.subArea ? ` ${intent.subArea}` : ''));
  const [showSuggestions, setShowSuggestions] = useState(false);
  const suggestionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (suggestionRef.current && !suggestionRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const availableFeatures = useMemo(() => {
    if (intent.purpose === InquiryPurpose.INVEST) return INVEST_FEATURES;
    return intent.propertyType === PropertyType.BUSINESS_SPACE 
      ? BUSINESS_FEATURES 
      : RESIDENTIAL_FEATURES;
  }, [intent.propertyType, intent.purpose]);

  const toggleFeature = (feature: string) => {
    const updatedFeatures = intent.selectedFeatures.includes(feature)
      ? intent.selectedFeatures.filter(f => f !== feature)
      : [...intent.selectedFeatures, feature];
    setIntent({ ...intent, selectedFeatures: updatedFeatures });
  };

  const agentGuidance = useMemo(() => {
    if (intent.purpose === InquiryPurpose.INVEST) {
      return "For investment, look for larger yards near transport hubs. Backroom demand is highest there.";
    }
    if (intent.propertyType === PropertyType.RESIDENTIAL) {
      return "Fencing and backup water are top priority in township rentals right now.";
    }
    return "Street frontage and foot traffic are critical for spazas and local retail.";
  }, [intent.propertyType, intent.purpose]);

  const filteredSuggestions = useMemo(() => {
    if (!locationInput) return SUPPORTED_TOWNSHIPS.slice(0, 5);
    const lowerInput = locationInput.toLowerCase();
    const results: any[] = [];
    SUPPORTED_TOWNSHIPS.forEach(t => {
      if (t.name.toLowerCase().includes(lowerInput) || t.aliases.some(a => a.toLowerCase().includes(lowerInput))) {
        results.push({ ...t, type: 'township' });
      }
      t.landmarks?.forEach(lm => {
        if (lm.toLowerCase().includes(lowerInput)) {
          results.push({ name: t.name, landmark: lm, region: t.region, type: 'landmark' });
        }
      });
    });
    return results.slice(0, 5);
  }, [locationInput]);

  const handleLocationSelect = (item: any) => {
    let displayValue = item.name;
    if (item.type === 'landmark') displayValue = `${item.name} (Near ${item.landmark})`;
    setLocationInput(displayValue);
    setIntent({ ...intent, location: item.name, subArea: item.subArea, nearLandmark: item.landmark });
    setShowSuggestions(false);
  };

  return (
    <div className="bg-white lg:rounded-[2rem] lg:p-8 lg:shadow-xl lg:shadow-slate-200/50 lg:border lg:border-slate-100 mb-6 lg:mb-10 w-full">
      <div className="space-y-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-6">
          <div className="space-y-3">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block">Select Your Intent</label>
            <div className="flex p-1 bg-slate-100 rounded-2xl overflow-x-auto no-scrollbar">
              {[
                { label: 'Rent', val: InquiryPurpose.RENT, type: PropertyType.RESIDENTIAL },
                { label: 'Hustle', val: InquiryPurpose.START_BUSINESS, type: PropertyType.BUSINESS_SPACE },
                { label: 'Home + Hustle', val: InquiryPurpose.RENT, type: PropertyType.MIXED_USE },
                { label: 'Invest', val: InquiryPurpose.INVEST, type: PropertyType.RESIDENTIAL }
              ].map(opt => (
                <button
                  key={opt.label}
                  onClick={() => setIntent({ 
                    ...intent, 
                    purpose: opt.val, 
                    propertyType: opt.type, 
                    selectedFeatures: [],
                    budgetMax: opt.val === InquiryPurpose.INVEST ? 800000 : 5000 
                  })}
                  className={`flex-1 py-3 px-2 whitespace-nowrap rounded-xl text-[10px] sm:text-xs font-black transition-all ${
                    (intent.purpose === opt.val && (intent.purpose === InquiryPurpose.INVEST || intent.propertyType === opt.type))
                    ? 'bg-white text-indigo-600 shadow-sm' 
                    : 'text-slate-500 hover:text-slate-700'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3 relative" ref={suggestionRef}>
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block">Target Area or Landmark</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
              </span>
              <input
                type="text"
                value={locationInput}
                onFocus={() => setShowSuggestions(true)}
                onChange={(e) => {
                  setLocationInput(e.target.value);
                  setShowSuggestions(true);
                  if (!e.target.value) setIntent({ ...intent, location: '', subArea: undefined, nearLandmark: undefined });
                }}
                className="w-full py-4 pl-10 pr-4 rounded-2xl border border-slate-200 text-sm font-bold text-slate-700 bg-slate-50 outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                placeholder="Where do you want to start?"
              />
            </div>
            {showSuggestions && (
              <div className="absolute top-full left-0 right-0 z-[60] mt-2 bg-white rounded-2xl shadow-2xl border border-slate-100 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
                <div className="p-2">
                  {filteredSuggestions.map((item, idx) => (
                    <button key={idx} type="button" onClick={() => handleLocationSelect(item)} className="w-full text-left px-4 py-3 rounded-xl hover:bg-slate-50 flex items-center justify-between transition-colors group">
                      <div className="flex flex-col">
                        <span className="text-sm font-black text-slate-900 group-hover:text-indigo-600">
                          {item.landmark || item.name}
                          {item.type === 'landmark' && <span className="text-slate-400 font-medium ml-2">in {item.name}</span>}
                        </span>
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{item.region}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="space-y-3">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block">
              {intent.purpose === InquiryPurpose.INVEST ? 'Investment Budget' : 'Monthly Rent Cap'}
            </label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-black text-sm">R</span>
              <input
                type="number"
                value={intent.budgetMax}
                onChange={(e) => setIntent({ ...intent, budgetMax: Number(e.target.value) })}
                className="w-full py-4 pl-9 pr-4 rounded-2xl border border-slate-200 text-sm font-bold text-slate-700 bg-slate-50 outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
              />
            </div>
          </div>
          <div className="space-y-3">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block">Timing</label>
            <select
              value={intent.urgency}
              onChange={(e) => setIntent({ ...intent, urgency: e.target.value as Urgency })}
              className="w-full py-4 px-4 rounded-2xl border border-slate-200 text-sm font-bold text-slate-700 bg-slate-50 outline-none focus:ring-2 focus:ring-indigo-500 appearance-none"
            >
              {Object.values(Urgency).map(u => <option key={u} value={u}>{u}</option>)}
            </select>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-100 space-y-6">
          <div className="bg-amber-50 border border-amber-100 rounded-2xl p-4 flex gap-4 animate-in slide-in-from-left duration-500">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center shrink-0">
               <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>
            </div>
            <p className="text-xs text-amber-900 font-bold leading-relaxed">
              <span className="text-amber-600 uppercase tracking-widest block mb-1">Expert Guide Tip</span>
              {agentGuidance}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {availableFeatures.map(feature => (
              <button
                key={feature}
                onClick={() => toggleFeature(feature)}
                className={`px-5 py-3 rounded-2xl text-xs font-bold border transition-all ${
                  intent.selectedFeatures.includes(feature)
                  ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg'
                  : 'bg-white border-slate-200 text-slate-600 hover:border-indigo-300'
                }`}
              >
                {feature}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
