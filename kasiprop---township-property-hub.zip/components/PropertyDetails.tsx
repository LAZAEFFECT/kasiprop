
import React, { useState, useMemo } from 'react';
import { Property, UserIntent, PropertyType, InquiryPurpose } from '../types';
import { Badge } from './Badge';
import { MatchAnalysis, ImprovementSuggestion } from '../services/geminiService';
import { InquiryForm } from './InquiryForm';

interface PropertyDetailsProps {
  property: Property;
  analysis: MatchAnalysis | null;
  userIntent: UserIntent;
  onBack: () => void;
}

export const PropertyDetails: React.FC<PropertyDetailsProps> = ({ property, analysis, userIntent, onBack }) => {
  const [showInquiry, setShowInquiry] = useState(false);
  const [inquirySent, setInquirySent] = useState(false);
  const [lastSummary, setLastSummary] = useState('');

  const isInvestmentGrade = property.yardSize || property.developmentPotential?.length;

  const roiEstimate = useMemo(() => {
    if (!property.developmentPotential) return null;
    const potentialUnits = property.developmentPotential.find(p => p.includes('Backroom')) ? 4 : 2;
    const monthlyExtra = potentialUnits * 2000;
    return {
      units: potentialUnits,
      monthly: monthlyExtra,
      yearly: monthlyExtra * 12
    };
  }, [property]);

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <div className="relative h-[45vh] sm:h-[55vh]">
        <img src={property.images[0]} alt={property.title} className="w-full h-full object-cover" />
        <button 
          onClick={onBack}
          className="absolute top-6 left-6 p-4 bg-white rounded-2xl shadow-2xl hover:bg-slate-50 transition-all z-20 hover:scale-105 active:scale-95"
        >
          <svg className="w-6 h-6 text-slate-900" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M15 19l-7-7 7-7"/></svg>
        </button>
      </div>

      <div className="max-w-4xl mx-auto px-4 -mt-20 relative z-10">
        <div className="bg-white rounded-[3rem] shadow-2xl overflow-hidden border border-slate-100">
          
          <div className="bg-slate-900 text-white p-8 sm:p-10">
             <div className="flex flex-col sm:flex-row gap-8 items-center justify-between">
                <div className="flex items-center gap-6">
                   <div className="w-16 h-16 rounded-2xl bg-indigo-500/20 flex items-center justify-center text-indigo-400">
                      <svg className="w-10 h-10" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>
                   </div>
                   <div>
                      <span className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.2em] mb-1 block">Property Verification</span>
                      <h3 className="text-xl font-black tracking-tight">{property.trustSignals.tenure}</h3>
                      <p className="text-sm text-slate-400 font-bold">{property.trustSignals.responseTime} • {property.trustSignals.successfulRentals} Successful Rentals</p>
                   </div>
                </div>
                {property.trustSignals.localReferrer && (
                   <div className="bg-white/5 border border-white/10 px-5 py-3 rounded-2xl flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center">
                         <svg className="w-5 h-5 text-green-400" fill="currentColor" viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/></svg>
                      </div>
                      <span className="text-xs font-black uppercase tracking-widest">{property.trustSignals.localReferrer}</span>
                   </div>
                )}
             </div>
          </div>

          <div className="p-8 sm:p-12">
            <div className="flex flex-wrap gap-2 mb-8">
               {property.propertyType === PropertyType.MIXED_USE && <Badge variant="verified">Home + Hustle Ready</Badge>}
               <Badge variant="info">Popular Listing ({property.communityPulse.saves} saves)</Badge>
               {property.isNegotiable && <Badge variant="success">Negotiable</Badge>}
               {isInvestmentGrade && <Badge variant="info" title="High ROI Potential">Investment Grade</Badge>}
            </div>

            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-8 mb-12">
              <div className="flex-1">
                <h1 className="text-4xl font-black text-slate-900 mb-4 tracking-tight leading-tight">{property.title}</h1>
                <div className="space-y-2">
                  {property.landmarks.map((l, i) => (
                    <p key={i} className="text-lg text-slate-500 font-bold flex items-center gap-3">
                      <div className="w-6 h-6 rounded-lg bg-slate-100 flex items-center justify-center text-slate-400 shrink-0">
                         <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/></svg>
                      </div>
                      {l}
                    </p>
                  ))}
                </div>
              </div>
              <div className="bg-indigo-50 px-8 py-6 rounded-[2rem] border border-indigo-100 text-center sm:text-right">
                <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest block mb-2">
                  {userIntent.purpose === InquiryPurpose.INVEST ? 'Asking Price' : 'Monthly Rent'}
                </span>
                <div className="text-4xl font-black text-indigo-600 mb-2">
                  R {property.price.toLocaleString()}
                </div>
                {property.marketPriceInsight && (
                  <p className="text-[10px] font-bold text-slate-400 italic leading-tight max-w-[150px]">
                    Note: {property.marketPriceInsight}
                  </p>
                )}
              </div>
            </div>

            {/* Renovation & Development Hub */}
            <section className="mb-12">
              <div className="bg-indigo-900 rounded-[2.5rem] p-8 sm:p-10 text-white relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full -mr-20 -mt-20 blur-3xl"></div>
                <div className="relative z-10">
                  <div className="flex items-center gap-3 mb-8">
                    <div className="w-12 h-12 rounded-2xl bg-indigo-500 flex items-center justify-center">
                      <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z"/></svg>
                    </div>
                    <div>
                      <h3 className="text-2xl font-black tracking-tight">Development & Improvement Hub</h3>
                      <p className="text-sm font-bold text-indigo-300 opacity-80">Actionable steps to maximize your ROI</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-10">
                    <div className="lg:col-span-2 space-y-6">
                      <h4 className="text-[10px] font-black text-indigo-300 uppercase tracking-widest mb-4">Improvement Roadmap</h4>
                      <div className="space-y-4">
                        {!analysis?.improvementSuggestions ? (
                          <div className="py-8 bg-white/5 rounded-3xl text-center">
                            <span className="text-xs font-bold opacity-60">Scanning for potential wins...</span>
                          </div>
                        ) : (
                          analysis.improvementSuggestions.map((item, idx) => (
                            <div key={idx} className="bg-white/5 border border-white/10 p-6 rounded-3xl hover:bg-white/10 transition-colors group">
                              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-3">
                                <h5 className="text-lg font-black text-white">{item.task}</h5>
                                <div className="flex gap-2">
                                  <span className="px-3 py-1 bg-indigo-500/20 text-indigo-300 rounded-lg text-[10px] font-black uppercase tracking-widest border border-indigo-500/20">
                                    {item.costEstimate}
                                  </span>
                                  <span className="px-3 py-1 bg-green-500/20 text-green-300 rounded-lg text-[10px] font-black uppercase tracking-widest border border-green-500/20">
                                    {item.roiImpact}
                                  </span>
                                </div>
                              </div>
                              <p className="text-sm text-slate-300 mb-4 font-medium opacity-90 leading-relaxed">{item.description}</p>
                              <div className="flex items-center justify-between pt-4 border-t border-white/10">
                                <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest flex items-center gap-2">
                                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                                  Required: {item.contractorType}
                                </span>
                                <button className="text-[10px] font-black text-white uppercase tracking-widest hover:text-indigo-300 transition-colors flex items-center gap-1 group-hover:translate-x-1 duration-200">
                                  Find Local Pro
                                  <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M9 5l7 7-7 7"/></svg>
                                </button>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>

                    <div className="space-y-8">
                       <div className="bg-white text-slate-900 p-8 rounded-[2rem] shadow-2xl">
                          <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest block mb-4">Agentic Next Steps</span>
                          <div className="space-y-3">
                            {[
                              { label: 'Save Renovation Plan', icon: 'M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z' },
                              { label: 'Chat Feasibility', icon: 'M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z' },
                              { label: 'Compare ROI', icon: 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z' }
                            ].map((step, i) => (
                              <button key={i} className="w-full flex items-center gap-4 p-4 rounded-2xl hover:bg-slate-50 transition-all border border-slate-100 group">
                                <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0 group-hover:bg-indigo-600 group-hover:text-white transition-all">
                                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={step.icon}/></svg>
                                </div>
                                <span className="text-xs font-black text-slate-700">{step.label}</span>
                              </button>
                            ))}
                          </div>
                       </div>

                       <div className="bg-white/5 border border-white/10 p-8 rounded-[2rem]">
                          <span className="text-[10px] font-black text-indigo-300 uppercase tracking-widest block mb-4">Market Potential</span>
                          <div className="space-y-4">
                            <div className="flex justify-between items-end">
                               <span className="text-xs font-bold text-slate-400">Demand Rank</span>
                               <span className="text-lg font-black text-white">Top 5%</span>
                            </div>
                            <div className="flex justify-between items-end">
                               <span className="text-xs font-bold text-slate-400">Tenant Score</span>
                               <span className="text-lg font-black text-green-400">High</span>
                            </div>
                            <p className="text-[10px] text-slate-500 leading-relaxed font-bold italic pt-4">
                              "Properties in {property.township} with gated sections see 40% faster tenant turnover."
                            </p>
                          </div>
                       </div>
                    </div>
                  </div>

                  <div className="bg-indigo-800/50 rounded-2xl p-6 border border-indigo-700/50">
                    <h4 className="text-[10px] font-black text-indigo-300 uppercase tracking-widest mb-4">Legal & Zoning Considerations</h4>
                    <ul className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm font-bold opacity-90">
                      <li className="flex items-start gap-3">
                        <svg className="w-5 h-5 text-indigo-400 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                        Building Plans: Backrooms require local municipality approval and zoning checks.
                      </li>
                      <li className="flex items-start gap-3">
                        <svg className="w-5 h-5 text-indigo-400 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                        Utility Loads: Check if the current prepaid meter can handle more than 3 households.
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              <div className="md:col-span-2 space-y-12">
                <section>
                  <h3 className="text-xl font-black text-slate-900 mb-6 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                    </div>
                    Agent Insight (The Real Deal)
                  </h3>
                  <div className="bg-slate-50 rounded-[2.5rem] p-8 border border-slate-200">
                    {!analysis ? (
                      <div className="py-10 text-center space-y-4">
                        <div className="w-10 h-10 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto" />
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Scanning local context...</p>
                      </div>
                    ) : (
                      <div className="space-y-8">
                        <div>
                          <h4 className="text-[10px] font-black text-green-600 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">Strengths</h4>
                          <div className="grid gap-3">
                            {analysis.strengths.map((s, idx) => (
                              <div key={idx} className="bg-white p-5 rounded-2xl text-sm font-bold text-slate-700 shadow-sm border border-slate-100 flex gap-3">
                                 <svg className="w-5 h-5 text-green-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"/></svg>
                                 {s}
                              </div>
                            ))}
                          </div>
                        </div>
                        <div>
                          <h4 className="text-[10px] font-black text-amber-600 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">Trade-offs</h4>
                          <div className="space-y-3">
                            {analysis.tradeOffs.map((t, idx) => (
                              <p key={idx} className="text-sm font-bold text-slate-500 flex gap-3 italic">
                                 <span className="text-amber-500">•</span> {t}
                              </p>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </section>

                <section>
                  <h3 className="text-xl font-black text-slate-900 mb-6">About the Space</h3>
                  <p className="text-slate-600 leading-relaxed text-lg mb-8 font-medium">{property.description}</p>
                  <div className="flex flex-wrap gap-3">
                    {property.features.map((f, i) => (
                      <span key={i} className="px-6 py-4 bg-white border border-slate-200 rounded-[1.5rem] text-sm font-black text-slate-800 shadow-sm">
                        {f}
                      </span>
                    ))}
                  </div>
                </section>
              </div>

              <div className="space-y-10">
                <section className="bg-white rounded-[2.5rem] p-8 border border-slate-200 shadow-xl">
                  <h3 className="text-md font-black text-slate-900 mb-6 uppercase tracking-widest">The Neighborhood</h3>
                  <div className="space-y-6">
                    {[
                      { label: 'Foot Traffic', value: property.areaIntelligence.footTraffic || 'Moderate' },
                      { label: 'Walkability', value: property.areaIntelligence.walkability },
                      { label: 'Security', value: property.areaIntelligence.safety },
                      { label: 'Noise', value: property.areaIntelligence.noise },
                    ].map((item, i) => (
                      <div key={i} className="border-b border-slate-50 pb-4 last:border-0">
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block mb-1">{item.label}</span>
                        <p className="text-sm font-black text-slate-800">{item.value}</p>
                      </div>
                    ))}
                  </div>
                </section>

                {analysis && (
                  <section className="bg-indigo-600 rounded-[2.5rem] p-8 text-white shadow-2xl">
                    <div className="flex justify-between items-center mb-6">
                      <span className="text-[10px] font-black uppercase tracking-[0.2em] opacity-80">Match Strength</span>
                      <span className="text-4xl font-black">{analysis.score}%</span>
                    </div>
                    <p className="text-sm leading-relaxed font-bold italic opacity-90">
                      "{analysis.reasoning}"
                    </p>
                  </section>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-slate-200 p-6 z-40">
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-6">
          <div className="hidden sm:block">
            <p className="text-2xl font-black text-slate-900 tracking-tight">R {property.price.toLocaleString()}</p>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Enquire with intent</p>
          </div>
          {inquirySent ? (
            <div className="w-full bg-green-500 text-white py-5 rounded-2xl font-black text-center animate-in zoom-in duration-300">
               Enquiry Sent! Expect a call soon.
            </div>
          ) : (
            <button 
              onClick={() => setShowInquiry(true)}
              className="w-full sm:w-auto flex-1 bg-indigo-600 hover:bg-indigo-700 text-white py-5 px-10 rounded-2xl font-black text-lg shadow-xl shadow-indigo-200 active:scale-95 transition-all group flex items-center justify-center gap-3"
            >
              Start {userIntent.purpose === InquiryPurpose.INVEST ? 'Investment' : 'Intent'} Enquiry
              <svg className="w-6 h-6 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M14 5l7 7-7 7"/></svg>
            </button>
          )}
        </div>
      </div>

      {showInquiry && (
        <InquiryForm 
          property={property} 
          userIntent={userIntent}
          onClose={() => setShowInquiry(false)}
          onSubmit={(summary) => {
            setLastSummary(summary);
            setShowInquiry(false);
            setInquirySent(true);
          }}
        />
      )}
    </div>
  );
};
