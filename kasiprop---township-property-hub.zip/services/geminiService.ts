
import { GoogleGenAI, Type } from "@google/genai";
import { Property, UserIntent, PropertyType, InquiryPurpose } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export interface ImprovementSuggestion {
  task: string;
  costEstimate: string;
  roiImpact: string;
  contractorType: string;
  description: string;
}

export interface MatchAnalysis {
  score: number;
  reasoning: string;
  summary: string;
  strengths: string[];
  tradeOffs: string[];
  improvementSuggestions?: ImprovementSuggestion[];
}

export const getPropertyMatchAnalysis = async (property: Property, intent: UserIntent): Promise<MatchAnalysis> => {
  const isInvest = intent.purpose === InquiryPurpose.INVEST;
  
  const prompt = `
    Analyze this property like a savvy township property guide and investment analyst.
    Use clear, plain, neutral language.
    
    PROPERTY:
    Title: ${property.title}
    Type: ${property.propertyType}
    Price: R${property.price}
    Yard Size: ${property.yardSize || 'Not specified'}
    Development Potential: ${property.developmentPotential?.join(', ') || 'Standard use'}
    Landmarks: ${property.landmarks.join(', ')}
    Foot Traffic: ${property.areaIntelligence.footTraffic || 'Moderate'}
    
    USER INTENT:
    Purpose: ${intent.purpose}
    Budget Max: R${intent.budgetMax}
    Location: ${intent.location}
    
    SPECIAL INSTRUCTIONS FOR INVEST/IMPROVEMENT:
    1. Identify suitability for backroom development or retail units based on yard size.
    2. Provide 3-4 actionable renovation or improvement suggestions (e.g., painting, fencing, security, adding units).
    3. For each suggestion, provide a realistic cost level (Low/Medium/High), ROI impact, and the type of local contractor needed.

    Rules for JSON Output:
    - score: 0-100.
    - reasoning: Familiar, expert explanation.
    - summary: Honest one-liner.
    - strengths: 2-3 points.
    - tradeOffs: 2 local realities.
    - improvementSuggestions: Array of objects with {task, costEstimate, roiImpact, contractorType, description}.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: { type: Type.NUMBER },
            reasoning: { type: Type.STRING },
            summary: { type: Type.STRING },
            strengths: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            tradeOffs: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            improvementSuggestions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  task: { type: Type.STRING },
                  costEstimate: { type: Type.STRING },
                  roiImpact: { type: Type.STRING },
                  contractorType: { type: Type.STRING },
                  description: { type: Type.STRING }
                },
                required: ["task", "costEstimate", "roiImpact", "contractorType", "description"]
              }
            }
          },
          required: ["score", "reasoning", "summary", "strengths", "tradeOffs", "improvementSuggestions"]
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Gemini Error:", error);
    const score = property.price <= intent.budgetMax ? 80 : 50;
    return {
      score,
      reasoning: `${score}% match — Worth checking if you're serious about the area.`,
      summary: "A practical spot with room to grow.",
      strengths: ["Solid walls and gate.", "Close to local transport."],
      tradeOffs: ["Standard yard size.", "Needs some fixing up."],
      improvementSuggestions: [
        {
          task: "Fresh Exterior Paint",
          costEstimate: "R3,000 - R5,000",
          roiImpact: "Boosts rental appeal",
          contractorType: "Local Painter",
          description: "A clean coat of paint makes the yard feel premium to new tenants."
        },
        {
          task: "Security Gate Upgrade",
          costEstimate: "R4,500 - R7,000",
          roiImpact: "Higher safety premium",
          contractorType: "Welding Contractor",
          description: "Reinforcing the main gate allows you to charge R200-R300 more per month."
        }
      ]
    };
  }
};
