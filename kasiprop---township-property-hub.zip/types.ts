
export enum PropertyType {
  RESIDENTIAL = 'residential',
  BUSINESS_SPACE = 'business_space',
  MIXED_USE = 'mixed_use'
}

export enum BusinessSubtype {
  SPAZA = 'Spaza',
  RETAIL = 'Retail',
  WAREHOUSE = 'Warehouse',
  SALON = 'Salon',
  WORKSHOP = 'Workshop'
}

export enum Urgency {
  IMMEDIATE = 'Within 7 days',
  MONTH = 'Within 30 days',
  FLEXIBLE = 'Flexible'
}

export enum InquiryPurpose {
  RENT = 'Rent',
  BUY = 'Buy',
  INVEST = 'Invest',
  START_BUSINESS = 'Start Business'
}

export interface UserIntent {
  budgetMin: number;
  budgetMax: number;
  propertyType: PropertyType;
  businessSubtype?: BusinessSubtype;
  purpose: InquiryPurpose;
  location: string;
  subArea?: string;
  nearLandmark?: string;
  urgency: Urgency;
  selectedFeatures: string[];
}

export interface Property {
  id: string;
  title: string;
  description: string;
  price: number;
  isNegotiable: boolean;
  marketPriceInsight?: string;
  location: string;
  township: string;
  landmarks: string[];
  propertyType: PropertyType;
  businessSubtype?: BusinessSubtype;
  images: string[];
  verified: boolean;
  yardSize?: string; // e.g., "350sqm"
  developmentPotential?: string[]; // e.g., ["Backrooms", "Spaza"]
  trustSignals: {
    tenure: string;
    responseTime: string;
    successfulRentals: number;
    localReferrer?: string;
  };
  lastUpdated: Date;
  availabilityConfirmed: boolean;
  communityPulse: {
    recentEnquiries: number;
    saves: number;
  };
  features: string[];
  areaIntelligence: {
    noise: 'Quiet' | 'Moderate' | 'Busy';
    walkability: string;
    commute: string;
    safety: string;
    footTraffic?: string;
  };
}

export interface Inquiry {
  propertyId: string;
  intent: UserIntent;
  purpose: InquiryPurpose;
  questions: string;
  summary: string;
  timestamp: number;
}
